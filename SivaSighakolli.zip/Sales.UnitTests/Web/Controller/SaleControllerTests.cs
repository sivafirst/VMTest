﻿using Microsoft.AspNetCore.Mvc;
using Moq;
using Sales.Domain.Model;
using Sales.Domain.Services;
using Sales.Web.Controllers;
using Sales.Web.Models;

namespace Sales.UnitTests.Web.Controller
{
    [TestClass]
    public class SaleControllerTests
    {
        [TestMethod]
        public async Task Index_ReturnsViewWithCorrectModel()
        {
            // Arrange
            var mockSaleService = new Mock<ISaleService>();
            var testData = new List<Sale> { new Sale { Segment = "test", Country = "test", Product = "test" } };

            mockSaleService.Setup(m => m.GetSalesData()).ReturnsAsync(testData);

            var controller = new SaleController(mockSaleService.Object);

            // Act
            var result = await controller.Index() as ViewResult;

            // Assert
            var model = result.ViewData.Model as SaleSummaryViewModel;
            Assert.AreEqual(testData.Count, model.SegementSummarySaleViewModel.Count());
            Assert.AreEqual(testData.Count, model.CountrySummarySaleViewModel.Count());
            Assert.AreEqual(testData.Count, model.ProductSummarySaleViewModel.Count());
        }
    }
}
