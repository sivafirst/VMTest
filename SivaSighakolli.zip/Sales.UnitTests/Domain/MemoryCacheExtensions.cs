﻿using Microsoft.Extensions.Caching.Memory;
using Moq;

namespace Sales.UnitTests.Domain
{
    public static class MemoryCacheExtensions
    {

        public static void SetupCacheHit(this Mock<IMemoryCache> mock, object key, object obj) =>
            mock
                .Setup(c => c.TryGetValue(key, out obj))
                .Returns(true);
    }
}
