﻿using CsvHelper.Configuration;
using Microsoft.Extensions.Caching.Memory;
using Moq;
using Sales.Domain.ConfigSetting;
using Sales.Domain.Model;
using Sales.Domain.Repositories.DataProvider;

namespace Sales.UnitTests.Domain.Repositories
{
    [TestClass]
    public class CachingCsvSaleDataReaderTests
    {
        private Mock<ISaleDataReader> mockDataReader;
        private Mock<IMemoryCache> mockMemoryCache;
        private Mock<ICacheEntry> mockCacheEntry;

        private ISaleDataReader sut;
        private const string TestFilePath = "test.csv";

        [TestInitialize]
        public void Setup()
        {
            var csvMetaData = new CsvMetaData
            {
                FilePath = TestFilePath
            };
            mockDataReader = new Mock<ISaleDataReader>();
            mockMemoryCache = new Mock<IMemoryCache>();
            mockCacheEntry = new Mock<ICacheEntry>();

            sut = new CachedCsvSaleDataReader(mockDataReader.Object, mockMemoryCache.Object, csvMetaData);

        }

        [TestMethod]
        public void GetData_CachesDataAndReturnsCorrectResult()
        {
            // Arrange      
            var testData = new List<Sale> { new Sale() };
            var testMap = new SaleMap();

            mockDataReader.Setup(m => m.GetData(testMap)).ReturnsAsync(testData);
            mockMemoryCache.Setup(m => m.CreateEntry(It.IsAny<object>())).Returns(mockCacheEntry.Object);

            // Act
            var result = sut.GetData(testMap);

            // Assert
            Assert.IsNotNull(result);
            mockDataReader.Verify(m => m.GetData(testMap), Times.Once);
            mockMemoryCache.Verify(m => m.CreateEntry(TestFilePath), Times.Once);
        }

        [TestMethod]
        public void GetData_ReturnsCachedDataWhenAvailable()
        {
            // Arrange
            var testData = new List<Sale> { new Sale() };
            var testMap = new SaleMap();
            mockMemoryCache.SetupCacheHit(TestFilePath, testData);
            // Act
            var result = sut.GetData(testMap);

            // Assert
            Assert.IsNotNull(result);
            mockDataReader.Verify(m => m.GetData<Sale>(It.IsAny<ClassMap<Sale>>()), Times.Never);
        }
    }
}
