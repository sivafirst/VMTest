﻿using Moq;
using Sales.Domain.Model;
using Sales.Domain.Repositories.DataProvider;
using Sales.Domain.Repositories;

namespace Sales.UnitTests.Domain.Repositories
{
    [TestClass]
    public class SaleRepositoryTests
    {
        [TestMethod]
        public async Task GetAll_ReturnsAllSales()
        {
            // Arrange
            var mockDataReader = new Mock<ISaleDataReader>();
            var testData = new List<Sale> { new Sale { Segment = "test", Country = "test", Product="test" } };

            mockDataReader.Setup(m => m.GetData<Sale>(It.IsAny<SaleMap>())).ReturnsAsync(testData);

            var repository = new SaleRepository(mockDataReader.Object);

            // Act
            var result = await repository.GetAll();

            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Count() == 1);
        }
    }
}
