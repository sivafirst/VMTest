﻿using Moq;
using Sales.Domain.Model;
using Sales.Domain.Repositories;
using Sales.Domain.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sales.UnitTests.Domain.Services
{
    [TestClass]
    public class SaleServiceTests
    {
        [TestMethod]
        public async Task GetAllSales_ReturnsAllSales()
        {
            // Arrange
            var mockSaleRepository = new Mock<ISaleRepository>();
            var testData = new List<Sale> { new Sale { Segment = "test", Country = "test", Product = "test" } };

            mockSaleRepository.Setup(m => m.GetAll()).ReturnsAsync(testData);

            var service = new SaleService(mockSaleRepository.Object);

            // Act
            var result = await service.GetSalesData();

            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Count() == 1);
        }
    }
}
