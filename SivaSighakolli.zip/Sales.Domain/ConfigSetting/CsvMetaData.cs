﻿namespace Sales.Domain.ConfigSetting
{
    public class CsvMetaData
    {
        public string FilePath { get; set; }
        public int CacheInSecs { get; set; }
    }
}