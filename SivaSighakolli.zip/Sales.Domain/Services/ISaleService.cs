﻿using Sales.Domain.Model;
using System.Collections.Generic;

namespace Sales.Domain.Services
{
    public interface ISaleService
    {
        Task<IEnumerable<Sale>> GetSalesData();
    }
}