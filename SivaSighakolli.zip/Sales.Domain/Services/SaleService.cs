﻿using Sales.Domain.Model;
using Sales.Domain.Repositories;

namespace Sales.Domain.Services
{
    public class SaleService : ISaleService
    {
        private readonly ISaleRepository _saleRepository;

        public SaleService(ISaleRepository saleRepository)
        {
            _saleRepository = saleRepository;
        }

        public async Task<IEnumerable<Sale>> GetSalesData()
        {
            return await _saleRepository.GetAll();
        }
    }
}
