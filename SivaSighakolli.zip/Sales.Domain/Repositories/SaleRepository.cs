﻿using Sales.Domain.Model;
using Sales.Domain.Repositories.DataProvider;

namespace Sales.Domain.Repositories
{
    public class SaleRepository : ISaleRepository
    {
        private readonly ISaleDataReader _saleDataReader;

        public SaleRepository(ISaleDataReader  saleDataReader)
        {
            _saleDataReader = saleDataReader;
        }

        public async Task<IEnumerable<Sale>> GetAll()
        {
            return await _saleDataReader.GetData<Sale>(new SaleMap());
        }
    }
}
