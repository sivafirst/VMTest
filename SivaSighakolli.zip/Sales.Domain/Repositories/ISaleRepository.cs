﻿using Sales.Domain.Model;

namespace Sales.Domain.Repositories
{
    public interface ISaleRepository
    {
        Task<IEnumerable<Sale>> GetAll();
    }
}
