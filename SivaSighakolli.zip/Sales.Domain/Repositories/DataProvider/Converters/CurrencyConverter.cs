﻿using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;
using System.Globalization;

namespace Sales.Domain.Repositories.DataProvider
{
    public class CurrencyConverter : ITypeConverter
    {
        public object ConvertFromString(string text, IReaderRow row, MemberMapData memberMapData)
        {
            var priceString = text.Replace("�", "");
            if (double.TryParse(priceString, NumberStyles.Number, CultureInfo.InvariantCulture, out var salePrice))
            {
                return salePrice;
            }
                
            return 0.0;            
        }

        public string ConvertToString(object value, IWriterRow row, MemberMapData memberMapData)
        {
            throw new NotImplementedException();
        }
    }
}