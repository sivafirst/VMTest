﻿using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;
using Microsoft.VisualBasic;
using System.Globalization;

namespace Sales.Domain.Repositories.DataProvider
{
    public class DateStringConverter : ITypeConverter
    {
        private readonly string _dateFormat;
        private readonly CultureInfo _CultureInfo;
        private readonly DateTimeStyles _DateTimeStyles;

        public DateStringConverter(string dateFormat) :
    this(dateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None)
        { }

        public DateStringConverter(string dateFormat, CultureInfo cultureInfo, DateTimeStyles dateTimeStyles)
        {
            _dateFormat = dateFormat;
            _CultureInfo = cultureInfo;
            _DateTimeStyles = dateTimeStyles;
        }

        public object ConvertFromString(string text, IReaderRow row, MemberMapData memberMapData)
        {
            string formattedDateString = string.Empty;
            if (DateTime.TryParseExact(text, _dateFormat, _CultureInfo, _DateTimeStyles, out DateTime dateObj))
            {
                return dateObj;
            }
            return null;
        }

        public string ConvertToString(object value, IWriterRow row, MemberMapData memberMapData)
        {
            throw new NotImplementedException();
        }
    }
}