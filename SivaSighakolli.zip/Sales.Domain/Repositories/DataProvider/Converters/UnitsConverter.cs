﻿using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;
using System.Globalization;

namespace Sales.Domain.Repositories.DataProvider
{
    internal class UnitsConverter : ITypeConverter
    {
        public object ConvertFromString(string text, IReaderRow row, MemberMapData memberMapData)
        {
            var unitString = text.Replace(" ", "");
            if (double.TryParse(unitString, NumberStyles.Number, CultureInfo.InvariantCulture, out var unitSold))
            {
                return unitSold;
            }

            return 0.0;
        }

        public string ConvertToString(object value, IWriterRow row, MemberMapData memberMapData)
        {
            throw new NotImplementedException();
        }
    }
}