﻿using CsvHelper;
using CsvHelper.Configuration;
using Sales.Domain.ConfigSetting;
using System.Globalization;

namespace Sales.Domain.Repositories.DataProvider
{
    public class CsvSaleDataReader : ISaleDataReader
    {
        private readonly CsvMetaData _csvMetaData;

        public CsvSaleDataReader(CsvMetaData csvMetaData)
        {
            _csvMetaData = csvMetaData;
        }

        public async Task<IEnumerable<T>> GetData<T>(ClassMap<T> map)
        {
            using (var reader = new StreamReader(_csvMetaData.FilePath))
            {
                var config = new CsvHelper.Configuration.CsvConfiguration(CultureInfo.InvariantCulture)
                {
                    HasHeaderRecord = true,
                    PrepareHeaderForMatch = args => args.Header.Replace(" ", "")
                };

                using (var csv = new CsvReader(reader, config))
                {
                    csv.Context.RegisterClassMap(map);
                    var records = new List<T>();
                    while (await csv.ReadAsync())
                    {
                        var record = csv.GetRecord<T>();
                        records.Add(record);
                    }
                    return records;
                }
            }
            
        }
    }
}
