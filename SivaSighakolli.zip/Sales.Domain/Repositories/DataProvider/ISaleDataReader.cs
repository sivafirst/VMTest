﻿using CsvHelper.Configuration;

namespace Sales.Domain.Repositories.DataProvider
{
    public interface ISaleDataReader
    {
        Task<IEnumerable<T>> GetData<T>(ClassMap<T> map);
    }
}
