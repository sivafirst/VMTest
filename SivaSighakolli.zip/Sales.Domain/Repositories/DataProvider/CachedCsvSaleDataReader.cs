﻿using CsvHelper.Configuration;
using Microsoft.Extensions.Caching.Memory;
using Sales.Domain.ConfigSetting;

namespace Sales.Domain.Repositories.DataProvider
{
    public class CachedCsvSaleDataReader : ISaleDataReader
    {
        private readonly ISaleDataReader _saleDataReader;
        private readonly IMemoryCache _cache;
        private readonly CsvMetaData _csvMetaData;

        public CachedCsvSaleDataReader(ISaleDataReader saleDataReader, IMemoryCache cache, CsvMetaData csvMetaData)
        {
            _saleDataReader = saleDataReader;
            _cache = cache;
            _csvMetaData = csvMetaData;
        }

        public async Task<IEnumerable<T>> GetData<T>(ClassMap<T> map)
        {
            if (!_cache.TryGetValue(_csvMetaData.FilePath, out IEnumerable<T> data))
            {
                data = await _saleDataReader.GetData<T>(map);
                _cache.Set(_csvMetaData.FilePath, data, TimeSpan.FromSeconds(_csvMetaData.CacheInSecs));
            }

            return data;
        }
    }
}
