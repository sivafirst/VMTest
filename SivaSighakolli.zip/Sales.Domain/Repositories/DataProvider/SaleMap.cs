﻿using CsvHelper.Configuration;
using Sales.Domain.Model;

namespace Sales.Domain.Repositories.DataProvider
{
    public class SaleMap : ClassMap<Sale>
    {
        public SaleMap()
        {
            Map(m => m.Segment);
            Map(m => m.Country);
            Map(m => m.Product);
            Map(m => m.DiscountBand).Name("Discount Band");
            Map(m => m.UnitsSold).Name("Units Sold").TypeConverter(new UnitsConverter());
            Map(m => m.Date).TypeConverter(new DateStringConverter("dd/MM/yyyy"));
            Map(m => m.SalePrice).Name("Sale Price").TypeConverter(new CurrencyConverter());
            Map(m => m.ManufacturingPrice).Name("Manufacturing Price").TypeConverter(new CurrencyConverter());

        }
    }
}
