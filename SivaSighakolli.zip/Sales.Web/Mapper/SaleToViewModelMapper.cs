﻿using Sales.Domain.Model;
using Sales.Web.Models;
using System.Collections.Generic;

namespace Sales.Web.Mapper
{
    public class SaleToViewModelMapper
    {
        public SaleSummaryViewModel MapToViewModel(IEnumerable<Sale> sales)
        {
            return new SaleSummaryViewModel
            {
                SegementSummarySaleViewModel = MapToSegementSummarySale(sales),
                CountrySummarySaleViewModel = MapToCountrySummarySale(sales),
                ProductSummarySaleViewModel = MapToProductSummarySale(sales)
            };
        }

        private IEnumerable<SegementSummarySaleViewModel> MapToSegementSummarySale(IEnumerable<Sale> sales)
        {
            return sales
            .GroupBy(s => s.Segment)
            .Select(g => new SegementSummarySaleViewModel
             {
                Segment = g.Key,
                TotalSales = g.Sum(s => s.SalePrice * s.UnitsSold),
                TotalUnits = g.Sum(s => s.UnitsSold)
             })
             .ToList();
        }

        private IEnumerable<CountrySummarySaleViewModel> MapToCountrySummarySale(IEnumerable<Sale> sales)
        {
            return sales
            .GroupBy(s => s.Country)
            .Select(g => new CountrySummarySaleViewModel
            {
                Country = g.Key,
                TotalSales = g.Sum(s => s.SalePrice * s.UnitsSold),
                TotalUnits = g.Sum(s => s.UnitsSold)
            })
             .ToList();
        }

        private IEnumerable<ProductSummarySaleViewModel> MapToProductSummarySale(IEnumerable<Sale> sales)
        {
            return sales
            .GroupBy(s => s.Product)
            .Select(g => new ProductSummarySaleViewModel
            {
                Product = string.IsNullOrWhiteSpace(g.Key) ? "Un Known" : g.Key,
                TotalSales = g.Sum(s => s.SalePrice * s.UnitsSold),
                TotalUnits = g.Sum(s => s.UnitsSold)
            })
             .ToList();
        }
    }
}
