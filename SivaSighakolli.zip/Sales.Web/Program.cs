using Sales.Domain.ConfigSetting;
using Sales.Domain.Repositories;
using Sales.Domain.Repositories.DataProvider;
using Sales.Domain.Services;

var builder = WebApplication.CreateBuilder(args);

var baseDir = AppDomain.CurrentDomain.BaseDirectory;
var csvMetaData = new CsvMetaData();
builder.Configuration.GetSection(nameof(CsvMetaData)).Bind(csvMetaData);
csvMetaData.FilePath = $"{baseDir}AppData\\{csvMetaData.FilePath}";

builder.Services.AddSingleton(csvMetaData);
builder.Services.AddTransient<ISaleDataReader, CsvSaleDataReader>();
builder.Services.Decorate <ISaleDataReader, CachedCsvSaleDataReader>();
builder.Services.AddTransient<ISaleRepository, SaleRepository>();
builder.Services.AddTransient<ISaleService, SaleService>();

builder.Services.AddMemoryCache();

// Add services to the container.
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
