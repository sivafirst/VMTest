﻿using Microsoft.AspNetCore.Mvc;
using Sales.Domain.Services;
using Sales.Web.Mapper;
using Sales.Web.Models;

namespace Sales.Web.Controllers
{
    public class SaleController : Controller
    {
        private readonly ISaleService _saleService;

        public SaleController(ISaleService saleService) {
            _saleService = saleService;
        }

        public async Task<IActionResult> Index()
        {
            var salesData = await _saleService.GetSalesData();

            var viewmodelMapper = new SaleToViewModelMapper();
            var viewModel = viewmodelMapper.MapToViewModel(salesData);
            return View(viewModel);
        }
    }
}
