﻿namespace Sales.Web.Models
{
    public class CountrySummarySaleViewModel : BaseSaleViewModel
    {
        public string Country { get; set; }        
    }
}
