﻿namespace Sales.Web.Models
{
    public class SaleSummaryViewModel
    {
        public IEnumerable<SegementSummarySaleViewModel> SegementSummarySaleViewModel { get; set; }

        public IEnumerable<CountrySummarySaleViewModel> CountrySummarySaleViewModel { get; set; }

        public IEnumerable<ProductSummarySaleViewModel> ProductSummarySaleViewModel { get; set; }
    }
}
