﻿namespace Sales.Web.Models
{
    public class SegementSummarySaleViewModel : BaseSaleViewModel
    {
        public string Segment { get; set; }
    }
}
