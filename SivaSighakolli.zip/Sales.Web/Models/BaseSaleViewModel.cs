﻿namespace Sales.Web.Models
{
    public class BaseSaleViewModel
    {
        public Double TotalUnits { get; set; }

        public Double TotalSales { get; set; }
    }
}
