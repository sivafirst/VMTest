﻿namespace Sales.Web.Models
{
    public class ProductSummarySaleViewModel : BaseSaleViewModel
    {
        public string Product { get; set; }
    }
}
